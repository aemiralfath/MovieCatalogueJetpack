package com.aemiralfath.moviecatalogue.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}