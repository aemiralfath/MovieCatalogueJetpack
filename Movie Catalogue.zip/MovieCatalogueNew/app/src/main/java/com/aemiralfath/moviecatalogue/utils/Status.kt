package com.aemiralfath.moviecatalogue.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}