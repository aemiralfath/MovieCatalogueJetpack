package com.aemiralfath.moviecatalogue.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}